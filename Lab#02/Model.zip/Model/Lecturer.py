#!/usr/bin/python
#-*- coding: utf-8 -*-

from ResearchAssociate import ResearchAssociate

class Lecturer(ResearchAssociate):
    pass
