#!/usr/bin/python
#-*- coding: utf-8 -*-

class Authorize:
    def __init__(self):
        self.session = None
        self.token = None
        self.userId = None

    def authorize(self, ):
        pass

