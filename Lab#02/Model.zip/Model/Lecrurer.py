#!/usr/bin/python
#-*- coding: utf-8 -*-

class Lecrurer:
    def __init__(self):
        self.id = None
        self.Attribute1 = None

    def createTask(self, ):
        pass

    def accessTasks(self, ):
        pass

    def viewStudentsGrade(self, ):
        pass

