#!/usr/bin/python
#-*- coding: utf-8 -*-

class Course:
    def __init__(self):
        self.courseCode = None
        self.title = None
        self.creditHours = None
        self.outline = None

