#!/usr/bin/python
#-*- coding: utf-8 -*-

from Person import Person

class Employee(Person):
    def __init__(self):
        self.eId = None

