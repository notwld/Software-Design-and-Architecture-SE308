#!/usr/bin/python
#-*- coding: utf-8 -*-

class Team:
    def __init__(self):
        self.name = None

