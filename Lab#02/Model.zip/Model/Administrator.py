#!/usr/bin/python
#-*- coding: utf-8 -*-

class Administrator:
    def __init__(self):
        self.id = None

    def allocateCertificates(self, ):
        pass

    def createCourse(self, ):
        pass

    def deleteCourse(self, ):
        pass

    def computeGrades(self, ):
        pass

