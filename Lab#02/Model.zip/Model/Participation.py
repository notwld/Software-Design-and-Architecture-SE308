#!/usr/bin/python
#-*- coding: utf-8 -*-

class Participation:
    def __init__(self):
        self.hours = None

