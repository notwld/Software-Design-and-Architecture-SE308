#!/usr/bin/python
#-*- coding: utf-8 -*-

from User import User

class Student(User):
    def __init__(self):
        self.id = None

    def takeCourse(self, ):
        pass

    def uploadPaper(self, ):
        pass

