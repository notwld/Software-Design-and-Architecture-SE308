#!/usr/bin/python
#-*- coding: utf-8 -*-

class Organization:
    def __init__(self):
        self.name = None
        self.Attribute1 = None

