#!/usr/bin/python
#-*- coding: utf-8 -*-

from Employee import Employee

class ResearchAssociate(Employee):
    def __init__(self):
        self.fieldOfStudy = None

    def takeLecture(self, lecId):
        pass

