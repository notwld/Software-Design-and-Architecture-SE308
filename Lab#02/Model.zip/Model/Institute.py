#!/usr/bin/python
#-*- coding: utf-8 -*-

class Institute:
    def __init__(self):
        self.name = None
        self.address = None

