#!/usr/bin/python
#-*- coding: utf-8 -*-

class Project:
    def __init__(self):
        self.name = None
        self.startDate = None
        self.endDate = None
        self.budget = None

    def validateDuration(self, ):
        pass

