#!/usr/bin/python
#-*- coding: utf-8 -*-

class Faculty:
    def __init__(self):
        self.id = None
        self.name = None

