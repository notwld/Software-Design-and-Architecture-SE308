#!/usr/bin/python
#-*- coding: utf-8 -*-

class EmployeeRole:
    def __init__(self):
        self.title = None

