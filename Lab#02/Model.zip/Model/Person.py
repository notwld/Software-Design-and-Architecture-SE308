#!/usr/bin/python
#-*- coding: utf-8 -*-

class Person:
    def __init__(self):
        self.id = None
        self.name = None
        self.availableHours = None
        self.minHours = None
        self.maxHours = None

    def determineAvailablity(self, ):
        pass

    def validateAvailabilty(self, ):
        pass

